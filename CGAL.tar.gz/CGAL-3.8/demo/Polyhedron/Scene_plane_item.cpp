#include "Scene_plane_item.h"

#include "Scene_plane_item.moc"
