#include "Scene_c2t3_item.h"

#include "Scene_c2t3_item.moc"
