#ifndef IMAGE_TYPE_FWD_H
#define IMAGE_TYPE_FWD_H

namespace CGAL {
  class Image_3;
}

#endif // IMAGE_TYPE_FWD_H
