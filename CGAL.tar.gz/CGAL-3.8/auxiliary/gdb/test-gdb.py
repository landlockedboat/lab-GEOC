#!/usr/bin/python

import sys
import os
import gdb

sys.path.insert(0, os.getcwd() + '/python')

import CGAL.printers
